# Aurrum Careers WordPress Theme

1. Copy `aurrum-careers` to `wp-content/themes/`.
2. In WordPress, activate **Aurrum Careers**.
3. Create pages called **About** and **Contact**, add them to the Primary navigation, and set the front page in **Settings > Reading**. The included `front-page.php` renders the homepage automatically.

The paper background image is bundled in `assets/images/`.

The bundled Zenz launcher calls the local WordPress REST endpoint at `/wp-json/aurrum/v1/chat`. Replace `aurrum_chat()` with an authenticated AI service when production content requires it.
