(() => {
  const chat = document.createElement('aside');
  chat.className = 'aurrum-zenz';
  chat.innerHTML = `<header><strong>Zenz</strong><button class="aurrum-zenz__voice" type="button">Voice on</button></header><p class="aurrum-zenz__message"></p><form><input aria-label="Ask Zenz" placeholder="Ask Zenz a career question"><button class="aurrum-zenz__send">Ask</button></form>`;
  document.body.append(chat);
  const message = chat.querySelector('.aurrum-zenz__message'); message.textContent = aurrumTheme.welcome;
  let voice = true;
  chat.querySelector('.aurrum-zenz__voice').addEventListener('click', (event) => { voice = !voice; event.currentTarget.textContent = voice ? 'Voice on' : 'Voice off'; });
  chat.querySelector('form').addEventListener('submit', async (event) => { event.preventDefault(); const input = chat.querySelector('input'); const value = input.value.trim(); if (!value) return; message.textContent = 'Zenz is thinking…'; try { const response = await fetch(aurrumTheme.restUrl, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': aurrumTheme.nonce }, body: JSON.stringify({ message: value }) }); const data = await response.json(); message.textContent = data.message; if (voice && 'speechSynthesis' in window) { speechSynthesis.cancel(); const utterance = new SpeechSynthesisUtterance(data.message); utterance.lang = 'en-GB'; speechSynthesis.speak(utterance); } } catch { message.textContent = 'I could not connect right now. Please try again.'; } input.value = ''; });
  const cards = document.querySelectorAll('[data-card]');
  if (!matchMedia('(prefers-reduced-motion: reduce)').matches && window.gsap) { window.gsap.from(cards, { opacity: 0, y: 32, duration: .65, stagger: .07, scrollTrigger: { trigger: cards[0]?.parentElement, start: 'top 80%' } }); }
})();
