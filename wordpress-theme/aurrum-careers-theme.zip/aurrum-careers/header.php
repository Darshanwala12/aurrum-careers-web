<?php if (!defined('ABSPATH')) exit; ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="aurrum-header">
  <a class="aurrum-brand" href="<?php echo esc_url(home_url('/')); ?>"><?php if (has_custom_logo()) { the_custom_logo(); } else { bloginfo('name'); } ?></a>
  <nav aria-label="<?php esc_attr_e('Primary navigation', 'aurrum-careers'); ?>"><?php wp_nav_menu(['theme_location' => 'primary', 'container' => false, 'fallback_cb' => 'aurrum_menu_fallback']); ?></nav>
  <a class="aurrum-trial" href="<?php echo esc_url(home_url('/contact/')); ?>"><?php esc_html_e('15-day free trial', 'aurrum-careers'); ?></a>
</header>
