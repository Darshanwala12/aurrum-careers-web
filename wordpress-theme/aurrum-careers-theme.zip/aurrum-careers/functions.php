<?php
declare(strict_types=1);

if (!defined('ABSPATH')) { exit; }

function aurrum_setup(): void {
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_theme_support('custom-logo');
  add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script']);
  register_nav_menus(['primary' => __('Primary navigation', 'aurrum-careers')]);
}
add_action('after_setup_theme', 'aurrum_setup');

function aurrum_menu_fallback(): void {
  echo '<ul>';
  wp_list_pages(['title_li' => '']);
  echo '</ul>';
}

function aurrum_assets(): void {
  $version = wp_get_theme()->get('Version');
  wp_enqueue_style('aurrum-careers', get_stylesheet_directory_uri() . '/assets/css/theme.css', [], $version);
  wp_enqueue_script('aurrum-careers', get_stylesheet_directory_uri() . '/assets/js/theme.js', [], $version, true);
  wp_localize_script('aurrum-careers', 'aurrumTheme', [
    'restUrl' => esc_url_raw(rest_url('aurrum/v1/chat')),
    'nonce' => wp_create_nonce('wp_rest'),
    'welcome' => get_theme_mod('aurrum_zenz_welcome', __('Hello, I’m Zenz. How can I help with your career today?', 'aurrum-careers')),
  ]);
}
add_action('wp_enqueue_scripts', 'aurrum_assets');

function aurrum_customize(WP_Customize_Manager $customizer): void {
  $customizer->add_section('aurrum_zenz', ['title' => __('Zenz chat', 'aurrum-careers'), 'priority' => 35]);
  $customizer->add_setting('aurrum_zenz_welcome', ['sanitize_callback' => 'sanitize_text_field', 'default' => __('Hello, I’m Zenz. How can I help with your career today?', 'aurrum-careers')]);
  $customizer->add_control('aurrum_zenz_welcome', ['section' => 'aurrum_zenz', 'label' => __('Welcome message', 'aurrum-careers'), 'type' => 'text']);
}
add_action('customize_register', 'aurrum_customize');

function aurrum_chat(WP_REST_Request $request): WP_REST_Response {
  $question = sanitize_text_field((string) $request->get_param('message'));
  $lower = strtolower($question);
  $answers = [
    'cv' => __('We tailor your CV and cover letter so your experience is clear, relevant, and ready for the roles you want.', 'aurrum-careers'),
    'interview' => __('We prepare you with realistic practice, focused feedback, and a clear interview strategy.', 'aurrum-careers'),
    'linkedin' => __('We strengthen your LinkedIn profile so recruiters see a consistent, professional story.', 'aurrum-careers'),
    'career' => __('We start with your direction, transferable skills, and target roles, then build a practical plan.', 'aurrum-careers'),
  ];
  foreach ($answers as $keyword => $answer) { if (str_contains($lower, $keyword)) return new WP_REST_Response(['message' => $answer, 'emotion' => 'encouraging', 'animation' => 'explaining']); }
  return new WP_REST_Response(['message' => __('Tell me where you are in your career and I’ll help you choose the best next step.', 'aurrum-careers'), 'emotion' => 'friendly', 'animation' => 'talking']);
}
add_action('rest_api_init', static function (): void { register_rest_route('aurrum/v1', '/chat', ['methods' => 'POST', 'callback' => 'aurrum_chat', 'permission_callback' => '__return_true', 'args' => ['message' => ['required' => true, 'sanitize_callback' => 'sanitize_text_field']]]); });
