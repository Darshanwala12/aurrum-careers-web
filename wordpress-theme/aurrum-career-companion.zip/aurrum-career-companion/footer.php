<footer class="aurrum-footer"><p>© <?php echo esc_html(wp_date('Y')); ?> <?php bloginfo('name'); ?></p></footer><?php wp_footer(); ?></body></html>
